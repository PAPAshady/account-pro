import Image from 'next/image';

export default function CategoryCard({ id, title, image, alt }) {
  return (
    <div key={id} className="group">
      <div className="group-hover:bg-primary hover:bg-hatching rounded-box-ltr bg-box relative flex h-full flex-col gap-4 px-2.5 pt-3.75 transition-all duration-300 xl:p-5! xl:pb-0!">
        <div className="flex h-full grow flex-col transition-colors duration-300">
          <p className="text-mainColor group-hover:text-blackColor text-sm font-light xl:text-[15px]!">
            اکانت های
          </p>
          <p className="group-hover:text-blackColor line-clamp-2 grow text-sm font-bold xl:text-[17px]!">
            {title}
          </p>
        </div>
        <div>
          <Image
            alt={alt}
            src={image}
            width={512}
            height={512}
            className="mx-auto size-13.75 grayscale-100 transition-colors duration-300 xl:size-23.75!"
          />
          <div className="group-hover:bg-primary absolute inset-0 size-full transition-colors duration-300 group-hover:mix-blend-color"></div>
        </div>
      </div>
    </div>
  );
}
